#include <stdio.h>
#define TRUE 1
#define FALSE 0

#define LIST_LEN 100
typedef int Data;

typedef struct ArrayList
{
	Data arr[LIST_LEN];  // �迭��� ����Ʈ�� ������ ����ü
	int numOfData;        // ����� �������� ��
	int curPosition;      // ������ ������ġ�� ���
}; ArrayList;

typedef ArrayList List;

void listInit(List* plist)
{
	(plist->numOfData) = 0;
	(plist->curPosition) = -1;
}

void insert(List* plist, Data data)
{
	if (plist->numOfData >= LIST_LEN)
	{
		puts("������ �Ұ����մϴ�.");
		return;
	}
	plist->arr[plist->numOfData] = data;
	(plist->numOfData)++;
}

int first(List* plist, Data* pdata)
{
	if (plist->numOfData == 0)
		return FALSE;

	(plist->curPosition) = 0;
	*pdata = plist->arr[0];

	return TRUE;
}

int next(List* plist, Data* pdata)
{
	if (plist->curPosition >= (plist->numOfData) - 1)
		return FALSE;

	(plist->curPosition)++;
	*pdata = plist->arr[plist->curPosition];
	return TRUE;
}

Data remove(List* plist)
{
	int pos = plist->curPosition;
	int num = plist->numOfData;
	int i;
	Data rdata = plist->arr[pos];

	for (i = pos; i < num -1; i++)
	{
		plist->arr[i] = plist->arr[i + 1];
	}

	(plist->numOfData)--;
	(plist->curPosition)--;

	return rdata;
}

int count(List* plist)
{
	return plist->numOfData;
}

int main()
{
	List list;

	int data;
	listInit(&list);

	insert(&list, 11);
	insert(&list, 11);
	insert(&list, 22);
	insert(&list, 22);
	insert(&list, 33);

	printf("������ ����: %d\n", count(&list));

	if (first(&list, &data))
	{
		printf("%d ", data);

		while (next(&list, &data))
		{
			printf("%d ", data);
		}
	}
	printf("\n\n");

	if (first(&list, &data))
	{
		if (data == 22)
			remove(&list);

		while (next(&list, &data))
		{
			if (data == 22)
				remove(&list);
		}
	}

	printf("������ ��: %d\n", count(&list));

	if (first(&list, &data))
	{
		printf("%d ", data);

		while (next(&list, &data))
			printf("%d ", data);
	}
	printf("\n\n");

	return 0;
}