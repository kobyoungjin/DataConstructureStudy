#include<stdio.h>
#define MAX_STACK_SIZE 100

int stack[MAX_STACK_SIZE];
int top = -1;

int isEmpty() {
    if (top < 0)
        return true;
    else
        return false;
}
int isFull() {
    if (top >= MAX_STACK_SIZE - 1)
        return true;
    else
        return false;
}

void push(int value) {
    if (isFull() == true)
        printf("������ ���� á���ϴ�.\n");
    else
        stack[++top] = value;
}

int pop() {
    if (isEmpty() == true)
        printf("������ ������ϴ�.\n");
    else
        return stack[top--];
}

int main() {

    push(3);
    push(5);
    push(12);
    printf("%d\n", pop());
    printf("%d\n", pop());
    printf("%d\n", pop());
    pop();
    return 0;
}