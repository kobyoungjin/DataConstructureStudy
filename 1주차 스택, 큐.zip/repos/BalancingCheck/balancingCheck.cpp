#include <stdio.h>
#include <string.h>
#define MAX_STACK_SIZE 100

int stack[MAX_STACK_SIZE];
int top = -1;

int isEmpty() {
	if (top < 0)
		return true;
	else
		return false;
}
int isFull() {
	if (top >= MAX_STACK_SIZE - 1)
		return true;
	else
		return false;
}

void push(int value) {
	if (isFull() == true)
		printf("������ ���� á���ϴ�.\n");
	else
		stack[++top] = value;
}

int pop() {
	if (isEmpty() == true)
		printf("������ ������ϴ�.\n");
	else
		return stack[top--];
}


bool balancingCheck(const char* text)
{
	for (int i = 0; i < strlen(text); i++)
	{
		if (text[i] == '(' || text[i] == '{' || text[i] == '[')
		{
			push(text[i]);
			continue;
		}
		if (text[i] == ')' || text[i] == '}' || text[i] == ']')
		{
			if (isEmpty())
				return false;

			char check = pop();
			if (check == '(' && text[i] != ')' || check == '{' && text[i] != '}' || check == '[' && text[i] != ']')
				return false;
		}
	}
	if (!isEmpty())
		return false;

	return true;
}

void checkingText(const char* text)
{
	bool result = balancingCheck(text);

	if (result == false)
		printf("No\n");
	else
		printf("Yes\n");
}

int main(void)
{
	checkingText("(a+sek)(");
}