#include <stdio.h>
#include <stdlib.h>

typedef struct bstnode {
    int data;
    struct bstnode* left;
    struct bstnode* right;
}Node;

Node* create_node() {
    Node* p = (Node*)malloc(sizeof(Node));

    if (p == NULL) {
        printf("Memory allocation failed!!\n");
        exit(1);
    }

    p->left = NULL;
    p->right = NULL;

    return p;
}

int getData(Node* node)
{
    return node->data;
}

void setData(Node* node, int data)
{
    node->data = data;
}

Node* getLeftSubTree(Node* node)
{
    return node->left;
}

Node* getRightSubTree(Node* node)
{
    return node->right;
}

void setLeftSubTree(Node* main, Node* sub)
{
    if (main->left != NULL)
    {
        free(main->left);
    }
    main->left = sub;
}

void setRightSubTree(Node* main, Node* sub)
{
    if (main->right != NULL)
    {
        free(main->right);
    }
    main->right = sub;
}

int main()
{
    Node* n1 = create_node();
    Node* n2 = create_node();
    Node* n3 = create_node();
    Node* n4 = create_node();

    setData(n1, 1);
    setData(n2, 2);
    setData(n3, 3);
    setData(n4, 4);

    setLeftSubTree(n1, n2);
    setRightSubTree(n1, n3);
    setLeftSubTree(n2, n4);

    printf("%d \n", getData(getLeftSubTree(n1)));
    printf("%d \n", getData(getLeftSubTree(getLeftSubTree(n1))));

    return 0;
}
